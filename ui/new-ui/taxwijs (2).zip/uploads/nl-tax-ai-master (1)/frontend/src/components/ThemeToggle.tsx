import { useTheme } from "../context/ThemeContext";

export default function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  return (
    <button
      onClick={toggleTheme}
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      title={isDark ? "Light mode" : "Dark mode"}
      style={{
        width: 36,
        height: 36,
        borderRadius: "var(--r-sm)",
        border: "1px solid var(--hairline-2)",
        background: "transparent",
        display: "grid",
        placeItems: "center",
        cursor: "pointer",
        color: "var(--ink-3)",
        flexShrink: 0,
        transition: "border-color .15s, color .15s, background .15s",
      }}
      onMouseOver={e => {
        e.currentTarget.style.borderColor = "var(--ink-3)";
        e.currentTarget.style.color = "var(--ink)";
      }}
      onMouseOut={e => {
        e.currentTarget.style.borderColor = "var(--hairline-2)";
        e.currentTarget.style.color = "var(--ink-3)";
      }}
    >
      {isDark ? (
        /* Sun — shown in dark mode to switch to light */
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <circle cx="12" cy="12" r="5" />
          <line x1="12" y1="1"     x2="12" y2="3" />
          <line x1="12" y1="21"    x2="12" y2="23" />
          <line x1="4.22" y1="4.22"  x2="5.64" y2="5.64" />
          <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
          <line x1="1"  y1="12"    x2="3"  y2="12" />
          <line x1="21" y1="12"    x2="23" y2="12" />
          <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
          <line x1="18.36" y1="5.64"  x2="19.78" y2="4.22" />
        </svg>
      ) : (
        /* Moon — shown in light mode to switch to dark */
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
        </svg>
      )}
    </button>
  );
}
